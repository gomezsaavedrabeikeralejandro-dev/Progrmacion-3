class OperacionesMatriz:

    def __init__(self):
        self.matriz_a = None
        self.matriz_b = None

    def crear_matriz(self, nombre):
        print(f"\n--- Ingresar Matriz {nombre} ---")
        while True:
            try:
                filas = int(input("Numero de filas: "))
                columnas = int(input("Numero de columnas: "))
                if filas <= 0 or columnas <= 0:
                    print("Las dimensiones deben ser mayores a 0.")
                    continue
                break
            except ValueError:
                print("Por favor ingrese un numero entero valido.")

        matriz = []
        for i in range(filas):
            fila = []
            for j in range(columnas):
                while True:
                    try:
                        val = float(input(f"  Elemento [{i+1}][{j+1}]: "))
                        fila.append(val)
                        break
                    except ValueError:
                        print("Ingrese un numero valido.")
            matriz.append(fila)
        return matriz

    def crear_vector(self):
        print("\n--- Ingresar Vector ---")
        while True:
            try:
                longitud = int(input("Longitud del vector: "))
                if longitud <= 0:
                    print("La Longitud debe ser mayor a 0.")
                    continue
                break
            except ValueError:
                print("Por favor ingrese un numero entero valido.")

        vector = []
        for i in range(longitud):
            while True:
                try:
                    val = float(input(f"  Elemento [{i+1}]: "))
                    vector.append(val)
                    break
                except ValueError:
                    print("Ingrese un numero valido.")
        return vector

    def imprimir_matriz(self, matriz, titulo="Matriz"):
        print(f"\n{titulo}:")
        for fila in matriz:
            formato = "  ".join(f"{val:8.4f}" for val in fila)
            print(f"  [ {formato} ]")

    def imprimir_vector(self, vector, titulo="Vector"):
        print(f"\n{titulo}:")
        formato = "  ".join(f"{val:8.4f}" for val in vector)
        print(f"  [ {formato} ]")

    def suma_matrices(self):
        print("\n========== SUMA DE MATRICES ==========")
        a = self.crear_matriz("A")
        b = self.crear_matriz("B")

        filas_a = len(a)
        columnas_a = len(a[0])
        filas_b = len(b)
        columnas_b = len(b[0])

        if filas_a != filas_b or columnas_a != columnas_b:
            print("\nError: Las matrices deben tener las mismas dimensiones para sumarlas.")
            print(f"  Matriz A: {filas_a}x{columnas_a}")
            print(f"  Matriz B: {filas_b}x{columnas_b}")
            return

        result = []
        for i in range(filas_a):
            fila = []
            for j in range(columnas_a):
                fila.append(a[i][j] + b[i][j])
            result.append(fila)

        self.imprimir_matriz(a, "Matriz A")
        self.imprimir_matriz(b, "Matriz B")
        self.imprimir_matriz(result, "Resultado A + B")

    def producto_matrices(self):
        print("\n========== PRODUCTO DE MATRICES ==========")
        a = self.crear_matriz("A")
        b = self.crear_matriz("B")

        filas_a = len(a)
        columnas_a = len(a[0])
        filas_b = len(b)
        columnas_b = len(b[0])

        if columnas_a != filas_b:
            print("\nError: El numero de columnas de A debe ser igual al numero de filas de B.")
            print(f"  Matriz A: {filas_a}x{columnas_a}")
            print(f"  Matriz B: {filas_b}x{columnas_b}")
            return

        result = []
        for i in range(filas_a):
            fila = []
            for j in range(columnas_b):
                total = 0.0
                for k in range(columnas_a):
                    total += a[i][k] * b[k][j]
                fila.append(total)
            result.append(fila)

        self.imprimir_matriz(a, "Matriz A")
        self.imprimir_matriz(b, "Matriz B")
        self.imprimir_matriz(result, "Resultado A x B")

    def calc_menor(self, matriz, fila, col):
        menor = []
        for i in range(len(matriz)):
            if i == fila:
                continue
            nueva_fila = []
            for j in range(len(matriz[i])):
                if j == col:
                    continue
                nueva_fila.append(matriz[i][j])
            menor.append(nueva_fila)
        return menor

    def _determinante(self, matriz):
        n = len(matriz)
        if n == 1:
            return matriz[0][0]
        if n == 2:
            return matriz[0][0] * matriz[1][1] - matriz[0][1] * matriz[1][0]
        det = 0.0
        for j in range(n):
            menor = self.calc_menor(matriz, 0, j)
            cofactor = ((-1) ** j) * matriz[0][j] * self._determinante(menor)
            det += cofactor
        return det

    def inversa_matriz(self):
        print("\n========== INVERSA DE UNA MATRIZ ==========")
        a = self.crear_matriz("A")

        filas = len(a)
        columnas = len(a[0])

        if filas != columnas:
            print("\nError: La matriz debe ser cuadrada para calcular su inversa.")
            return

        det = self._determinante(a)

        if abs(det) < 1e-10:
            print("\nError: La matriz es singular (determinante = 0), no tiene inversa.")
            return

        n = filas
        cofactores = []
        for i in range(n):
            fila = []
            for j in range(n):
                menor = self.calc_menor(a, i, j)
                cofactor = ((-1) ** (i + j)) * self._determinante(menor)
                fila.append(cofactor)
            cofactores.append(fila)

        
        adjunta = []
        for i in range(n):
            fila = []
            for j in range(n):
                fila.append(cofactores[j][i])
            adjunta.append(fila)

        
        inversa = []
        for i in range(n):
            fila = []
            for j in range(n):
                fila.append(adjunta[i][j] / det)
            inversa.append(fila)

        self.imprimir_matriz(a, "Matriz A")
        print(f"\n  Determinante: {det:.4f}")
        self.imprimir_matriz(inversa, "Inversa de A")

    def producto_matriz_vector(self):
        print("\n========== PRODUCTO MATRIZ POR VECTOR ==========")
        a = self.crear_matriz("A")
        v = self.crear_vector()

        columnas_a = len(a[0])
        longitud_v = len(v)

        if columnas_a != longitud_v:
            print("\nError: El numero de columnas de la matriz debe ser igual al Longitud del vector.")
            print(f"  Columnas de A: {columnas_a}")
            print(f"  Longitud del vector: {longitud_v}")
            return

        result = []
        for i in range(len(a)):
            total = 0.0
            for j in range(columnas_a):
                total += a[i][j] * v[j]
            result.append(total)

        self.imprimir_matriz(a, "Matriz A")
        self.imprimir_vector(v, "Vector v")
        self.imprimir_vector(result, "Resultado A x v")

    def run(self):
        True 
        while True:
            print("\n====== OPERACIONES CON MATRICES ======")
            print("  1. Suma de matrices")
            print("  2. Producto de matrices")
            print("  3. Inversa de una matriz")
            print("  4. Producto de una matriz por un vector")
            print("  0. Volver al menu principal")

            opcion = input("\nSeleccione una opcion: ").strip()

            if opcion == "1":
                self.suma_matrices()
            elif opcion == "2":
                self.producto_matrices()
            elif opcion == "3":
                self.inversa_matriz()
            elif opcion == "4":
                self.producto_matriz_vector()
            elif opcion == "0":
                break
            else:
                print("Opcion invalida. Por favor seleccione una opcion del menu.")

            if True:
                input("\nPresione ENTER para continuar...")
