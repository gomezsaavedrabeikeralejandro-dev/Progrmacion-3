import random
import time


class AlgoritmosOrdenamiento:

    def __init__(self):
        self.numeros = []
        self.n = 0

    def Generar_Lista(self):
        while True:
            try:
                self.n = int(input("\nIngrese la cantidad de numeros a ordenar: "))
                if self.n <= 0:
                    print("La cantidad debe ser mayor a 0.")
                    continue
                break
            except ValueError:
                print("Por favor ingrese un numero entero valido.")

        self.numeros = [round(random.uniform(-100.0, 100.0), 1) for _ in range(self.n)]
        print(f"\nLista generada con {self.n} numeros flotantes aleatorios.")

    def Imprimir_Lista(self, lst, titulo="Lista"):
        print(f"\n{titulo}:")
        if len(lst) <= 20:
            print("  ", lst)
        else:
            print("  Primeros 10:", lst[:10])
            print("  Ultimos 10: ", lst[-10:])

    def burbuja(self, lst):
        arr = lst[:]
        n = len(arr)
        for i in range(n - 1):
            for j in range(n - 1 - i):
                if arr[j] > arr[j + 1]:
                    arr[j], arr[j + 1] = arr[j + 1], arr[j]
        return arr

    def insercion(self, lst):
        arr = lst[:]
        n = len(arr)
        for i in range(1, n):
            key = arr[i]
            j = i - 1
            while j >= 0 and arr[j] > key:
                arr[j + 1] = arr[j]
                j -= 1
            arr[j + 1] = key
        return arr

    def seleccion(self, lst):
        arr = lst[:]
        n = len(arr)
        for i in range(n - 1):
            min_idx = i
            for j in range(i + 1, n):
                if arr[j] < arr[min_idx]:
                    min_idx = j
            arr[i], arr[min_idx] = arr[min_idx], arr[i]
        return arr

    def _merge(self, left, right):
        result = []
        i = 0
        j = 0
        while i < len(left) and j < len(right):
            if left[i] <= right[j]:
                result.append(left[i])
                i += 1
            else:
                result.append(right[j])
                j += 1
        while i < len(left):
            result.append(left[i])
            i += 1
        while j < len(right):
            result.append(right[j])
            j += 1
        return result

    def mergesort(self, lst):
        if len(lst) <= 1:
            return lst[:]
        mid = len(lst) // 2
        left = self.mergesort(lst[:mid])
        right = self.mergesort(lst[mid:])
        return self._merge(left, right)

    def python_sort(self, lst):
        arr = lst[:]
        arr.sort()
        return arr

    def sort_burbuja(self):
        if not self.numeros:
            print("\nPrimero debe generar una lista (opcion 1).")
            return
        print("\n========== ORDENAMIENTO BURBUJA ==========")
        self.Imprimir_Lista(self.numeros, "Lista original")
        result = self.burbuja(self.numeros)
        self.Imprimir_Lista(result, "Lista ordenada")
        

    def sort_insercion(self):
        if not self.numeros:
            print("\nPrimero debe generar una lista (opcion 1).")
            return
        print("\n========== ORDENAMIENTO INSERCION ==========")
        self.Imprimir_Lista(self.numeros, "Lista original")
        result = self.insercion(self.numeros)
        self.Imprimir_Lista(result, "Lista ordenada")
        

    def sort_seleccion(self):
        if not self.numeros:
            print("\nPrimero debe generar una lista (opcion 1).")
            return
        print("\n========== ORDENAMIENTO SELECCION ==========")
        self.Imprimir_Lista(self.numeros, "Lista original")
        result = self.seleccion(self.numeros)
        self.Imprimir_Lista(result, "Lista ordenada")
        

    def sort_mergesort(self):
        if not self.numeros:
            print("\nPrimero debe generar una lista (opcion 1).")
            return
        print("\n========== ORDENAMIENTO MERGESORT ==========")
        self.Imprimir_Lista(self.numeros, "Lista original")
        result = self.mergesort(self.numeros)
        self.Imprimir_Lista(result, "Lista ordenada")
        

    def sort_python(self):
        if not self.numeros:
            print("\nPrimero debe generar una lista (opcion 1).")
            return
        print("\n========== ORDENAMIENTO CON sort() DE PYTHON ==========")
        self.Imprimir_Lista(self.numeros, "Lista original")
        result = self.python_sort(self.numeros)
        self.Imprimir_Lista(result, "Lista ordenada")
        



    def run(self):
        while True:
            print("\n====== ALGORITMOS DE ORDENAMIENTO ======")
            print("  1. Generar nueva lista aleatoria")
            print("  2. Ordenamiento Burbuja")
            print("  3. Ordenamiento Insercion")
            print("  4. Ordenamiento Seleccion")
            print("  5. Ordenamiento Mergesort")
            print("  6. Ordenamiento con sort() de Python")
            print("  0. Volver al menu principal")


            opcion = input("\nSeleccione una opcion: ").strip()

            if opcion == "1":
                self.Generar_Lista()
            elif opcion == "2":
                self.sort_burbuja()
            elif opcion == "3":
                self.sort_insercion()
            elif opcion == "4":
                self.sort_seleccion()
            elif opcion == "5":
                self.sort_mergesort()
            elif opcion == "6":
                self.sort_python()
            elif opcion == "0":
                break
            else:
                print("Opcion invalida. Por favor seleccione una opcion del menu.")

            if True and opcion != "1":
                input("\nPresione ENTER para continuar...")
