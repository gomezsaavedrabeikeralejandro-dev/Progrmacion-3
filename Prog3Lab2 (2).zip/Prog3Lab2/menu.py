from OperacionesMatriz import OperacionesMatriz
from AlgoritmosOrdenamiento import AlgoritmosOrdenamiento
import os

def main():
    menu = Menu()
    menu.run()

class Menu:

    def __init__(self):
        self.matrix_ops = OperacionesMatriz()
        self.sorting = AlgoritmosOrdenamiento()

    def encabezado(self):
        os.system('cls')
        print("\n" + "=" * 40)
        print("        MENU PRINCIPAL")
        print("=" * 40)
        print("  1. Operaciones con Matrices")
        print("  2. Ordenamiento de Listas")
        print("  0. Salir")
        print("=" * 40)

    def run(self):
        
        while True:
            self.encabezado()
            opcion = input("\nSeleccione una opcion: ")

            if opcion == "1":
                self.matrix_ops.run()
            elif opcion == "2":
                self.sorting.run()
            elif opcion == "0":
                print("\nPrograma finalizado")
                break
            else:
                print("Opcion invalida. Por favor seleccione 0, 1 o 2.")


if __name__ == "__main__":
    main()